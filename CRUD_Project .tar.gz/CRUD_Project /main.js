require("dotenv").config();
const express = require("express");
const session = require("express-session");
const mongoose = require("mongoose");

const routes= require('./routes/routes')

const app = express();
const PORT = process.env.PORT || 6000;
const DB_URL=process.env.DB_URL;

/*----------Middlewares----------*/
app.use(express.static('public'));
app.use(express.static('uploads'));


app.use(express.urlencoded({extended:false}));
app.use(express.json());
app.use(session(
	{
		secret:"this_is_my_key_HADROUK_RAMZI",
		saveUninitialized: true,
		resave :false,

	}));
app.use((req, res, next)=>{
	res.locals.message=req.session.message;
	delete req.session.message;
	next();
});

/*---------- View Engine----------*/
app.set('view engine','ejs');

/*----------Conect To Database----------*/
mongoose.connect(DB_URL);
dbInfo= mongoose.connection;
dbInfo.on('error', error => console.log(error));
dbInfo.once('open', ()=> console.log("conected to DB"));

/*----------Http & routes----------*/
app.use('/',routes);



app.listen(PORT, (req, res) => {
  console.log(`server is working on: 127.0.0.1:${PORT}`);
});
