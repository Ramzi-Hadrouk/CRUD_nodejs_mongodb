const mongoose= require("mongoose")

/*----------Schema----------*/
const userSchema= mongoose.Schema({
name:  { type: String, require:true,},
email: { type: String, require:true,},
phone: { type: String, require:true,},
image: { type: String, require:true,},
created: { type: Date , require:true, default:Date.now ,},
})

/*----------Export----------*/
module.exports=mongoose.model('User', userSchema)